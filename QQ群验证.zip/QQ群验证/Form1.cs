﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Diagnostics;

namespace QQ群验证
{
    public partial class Form1 : Form
    {
        int i;//别动
        int a;//别动
        public Form1()
        {
            InitializeComponent();
        }

        private void webBrowser1_DocumentCompleted(object sender, WebBrowserDocumentCompletedEventArgs e)
        {
            Debug.WriteLine(webBrowser1 .Url.ToString ());
            string Url = "https://qun.qq.com/member.html#gid=你的群号";//别忘了这里！
            Uri uri = new Uri(Url);
            webBrowser1.Url = uri;
            string True = "验证成功想说的话";//验证成功想说的话
            string False = "验证失败想说的话";//验证失败想说的话

            if (webBrowser1.Url.ToString() == Url)
            {
                a++;
                string cookie = webBrowser1.Document.Cookie.ToString();
                Int64 qq = -1;
                try
                {
                    qq = Convert.ToInt64(GetMiddleStr(cookie, "p_uin=o", ";"));
                }
                catch { }
                _ = qq != -1 ? i++ : -1;//-1占位置的
                
                if (qq != -1 && i != 1)
                {
                    this.Hide();
                    MessageBox.Show(True, "验证成功！", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    //这里挂载下一个窗口
                    this.Close();
                }
            }
            else if (a >= 2)
            {
                this.Hide();
                MessageBox.Show(False, "提示", MessageBoxButtons.OK, MessageBoxIcon.Information);
                Application.Exit();
            }
           
        }
        private static string GetMiddleStr(string oldStr, string preStr, string nextStr)
        {
            string tempStr = oldStr.Substring(oldStr.IndexOf(preStr) + preStr.Length);
            tempStr = tempStr.Substring(0, tempStr.IndexOf(nextStr));
            return tempStr;

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
